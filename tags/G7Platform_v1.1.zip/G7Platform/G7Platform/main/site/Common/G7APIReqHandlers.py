#-*- coding: UTF-8 -*-
__author__ = 'helios'
'''
    该类作为接口基类
'''

from G7Platform.main.site.Common.G7ReqHandlers import *

class G7APIReqHandler(G7ReqHandler):
    """api请求基类"""

    pass

    
