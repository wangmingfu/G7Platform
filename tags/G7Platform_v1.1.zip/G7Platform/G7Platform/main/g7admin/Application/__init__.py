#-*- coding: UTF-8 -*-
__author__ = 'yuyang'

default_app_config = "Application.apps.ApplicationConfig"