#-*- coding: UTF-8 -*-
__author__ = 'yuyang'

from django.apps import AppConfig

class AccountConfig(AppConfig):
    name = 'Account'
    verbose_name = '账户'